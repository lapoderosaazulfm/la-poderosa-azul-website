LA PODEROSA AZUL FM — V4 CMS

The 7-page website design is preserved. Content appears automatically from content/*.json.

IMPORTANT: /admin is NOT ready to sign in until GitHub and OAuth are configured.
1. Create a PRIVATE GitHub repository and upload the extracted website files to its main branch.
2. Replace REPLACE_WITH_GITHUB_USERNAME/REPLACE_WITH_REPOSITORY in admin/config.yml.
3. Configure a trusted GitHub OAuth authentication service for Decap CMS on your hosting domain. A GitHub backend alone does not provide login. Configure OAuth and callback URLs per your provider documentation.
4. Deploy the site to Netlify from the GitHub repository with continuous deployment.
5. Open /admin and sign in via the configured OAuth flow. Editing content creates commits, and Netlify rebuilds.
6. To publish a video, paste a public YouTube link into Videos. Do not upload copyrighted content without rights.
7. Radio.co is intentionally left unconnected in radio-config.js.
8. News, programs, and sponsor content are empty until you publish actual entries.
9. If opening index.html locally via file://, browsers often block fetch of content/*.json; use a local HTTP server or Netlify preview.
10. Do not place credentials, tokens, or OAuth secrets in the public repository or website files.
