// RADIO.CO: add your official player embed HTML later between the backticks.
window.RADIOCO_EMBED_CODE = ``;
// Optional direct stream URL if provided by your station:
window.RADIO_STREAM_URL = "";
