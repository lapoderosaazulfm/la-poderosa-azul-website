// Replace with confirmed official links when available.
window.STATION_CONFIG = {youtube: "", email: "", whatsapp: ""};
