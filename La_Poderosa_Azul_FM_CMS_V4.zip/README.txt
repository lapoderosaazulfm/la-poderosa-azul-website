LA PODEROSA AZUL FM — MULTI-PAGE WEBSITE

Open index.html to preview locally. Upload the CONTENTS of this folder to Netlify (or upload the ZIP to a host that supports zip deployment).

Pages: index.html, en-vivo.html, programacion.html, locutores.html, noticias.html, publicidad.html, contacto.html

To connect Radio.co LAST: open radio-config.js and paste the official embed code between the backticks.
To configure official YouTube channel and station email: edit site-config.js.

Contact forms intentionally DO NOT send or store messages until the official email is configured. Afterward they open the visitor's email application; they are not backend-powered.
The website does not assert a live stream is connected or invent program schedules.
Photos: user-supplied station logo and studio/host photographs.
